"""UyarAI Plagiarism Detection System"""
